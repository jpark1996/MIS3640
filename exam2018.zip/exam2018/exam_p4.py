"""
What is the most interesting/funny/cool thing(s) about Python that you learned from this class or from somewhere else.

You can use code or a short paragraph to illustrate it.
"""
# Run the code below to see my Opinion! 
print ("I think python is such an intersting program because it literally can do anything from drawing to making a program. The most interesting thing I learned from this course is how to fetch the data from other website because it was very fun to see all these datas from python just by typing in some codes. To be really honest, I think I am having a hard time in this class because there are so many things to cover and sometimes it is hard to understand some parts. However, I am very thankful that I was able to learn Python and I should practice more on it in order to be a better at it.")