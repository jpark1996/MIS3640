def get_value(name):
    # return the value of given name
    sum_value = 0
    for character in name.lower():
        value = ord(character)-ord('a') + 1
        sum_value += value
    return sum_value


def get_name_list(file_name):
    name_list = []
    # load the txt file, get all the first names to name_list
    file_object = open(file_name, 'r')

    for line in file_object.readlines():
        # gives first name and last name in a list
        name = line.split()
        name_list.append(name[0])
    return name_list


def who_has_highest_value(name_list):
    # return the name with highest value among the given name_list
    highest = 0
    person = ''

    for name in name_list:
        value = get_value(name)
        # the name has a higher value than the current maximum
        if value > highest:
            person = name
            highest = value

    return person


def get_words(file_name):
    words = []

    # return a list of words
    file_object = open(file_name, 'r')

    for line in file_object.readlines():
        # get rid of the \n
        word = line[:-1]
        words.append(word)
    return words


def get_words_with_same_value(word_list, value):
    words = []
    # return a list of matched words

    for word in word_list:
        if value == get_value(word):
            words.append(word)

    if words == []:
        return None

    return words


def main():
    name_list = get_name_list('exam2018/roster.txt')
    word_list = get_words('exam2018/positive-words.txt')

    #part 1 of the question
    name = who_has_highest_value(name_list)
    print(name)

    #part 2 of the question
    words = get_words_with_same_value(word_list, 'Jonghyun')
    print(words)


if __name__ == '__main__':
    main()
