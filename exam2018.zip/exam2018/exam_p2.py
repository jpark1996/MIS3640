def process_file(file_name):
    """
    Given a file name, returns a list of lists [name, gender, births]
    HINT: https://stackoverflow.com/a/35340988/941742

    :param file_name: a string
    :return: a list of lists, [[name1, gender1, births1], [name2, gender2, births2]...]

    Example:
    process_file('yob1880.txt')
        will return
    [["Mary","F",7065], ["Anna","F",2604],...]

    """
    processed_list = []
    file_object = open('exam2018/babynames/'+file_name, 'r')

    for line in file_object.readlines():
        line = line[:-1]
        line_list = line.split(',')
        line_list[2] = int(line_list[2])
        processed_list.append(line_list)

    return processed_list


def total_births(year, gender):
    """

    :param year: an integer, between 1880 and 2010
    :return: an integer, the total births of all the babies in that year
    """
    file_name = 'yob'+str(year)+'.txt'
    people = process_file(file_name)
    total = 0
    for person in people:
        if person[1] == gender:
            total += person[2]
    return total


def proportion(name, gender, year):
    """

    :param name: a string, first name
    :param gender: a string, "F" or "M"
    :param year: an integer, between 1880 and 2010
    :return: a floating number, the proportion of babies with the given name to total births in given year
    """
    file_name = 'yob'+str(year)+'.txt'
    people = process_file(file_name)
    total_people = total_births(year, gender)

    for person in people:
        if person[0] == name and person[1] == gender:
            return person[2] / float(total_people)

    return 0.0



def highest_year(name, gender):
    """

    :param name: a string
    :param gender: a string, "F" or "M"
    :return: an integer, the year when the given name has the highest proportion over the years (among all the proportions of the same name in different years)
    """
    highest_prop = 0
    highest_yr = 0
    for year in range(1880, 2011):
        current = proportion(name, gender, year)
        if highest_prop < current:
            highest_prop = current
            highest_yr = year

    return highest_yr

def main():
    print(highest_year('John', 'M'))
    print(proportion('John', 'M',1980))

    print(highest_year('Sarah', 'F'))
    print(proportion('Sarah', 'F',1981))
    
    
if __name__ == '__main__':
    main()