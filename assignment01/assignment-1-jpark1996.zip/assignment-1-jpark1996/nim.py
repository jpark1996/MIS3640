#
# You need to replace 'pass' with your code
# I didnt necessaryily explain the pre-registerd code because it was already existed  + straighforward 

from random import randint
from math import log

# Define constant variables.
HUMAN = 0
COMPUTER = 1
SMART = 0
DUMB = 1

# Create the initial pile, determine the starting player and the computer's
# strategy.
pile = randint(10, 100)
turn = randint(0, 1)
strategy = randint(0, 1)


def nim(pile, turn, strategy):
    """
    return True if the winner is human, False if winner is computer.
    """
    # While the game is still being played.
    while pile > 0:
        if turn == COMPUTER:
            if pile == 1:
                # Take the last marble.
                print('The computer took the last marble.') # indicated that computer took the last marble 
                return True #end the function
            elif pile == 2: # when pile is only two left
                take = 1 # the amount of pile that computer take is 1 
                pile -= take # takes out the amount that was taken from the pile (figuring out reaming # of pile)
            elif strategy == DUMB:
                # Take a random, legal number of marbles from the pile.
                take = randint(1, round((pile - 1)/2)) # choose number between 1 and half amount of the pile (maxium) for take amount.
                pile -= take # takes out the amount that was taken from the pile (figuring out reaming # of pile)
            elif pile == 3 or pile == 7 or pile == 15 or pile == 31 or pile == 63:
                # The computer is smart, but can't make a smart move.
                # Take a random, legal number of marbles from the pile.
                take = randint(1, round(pile -1)/2) # choose number between 1 and half amount of the pile (maximum) for take amount
                pile -= take # takes out the amount that was taken from the pile (figuring out reaming # of pile)
            else:
                # The computer is smart and can make a smart move.
                # Take marbles so that the pile will be be a power of 2, minus
                # 1.
                take = 0 # default number of take for function below
                for i in range(7): # for in range of 7 (set range as seven because the maximum nummber of pile is 100 and if it passes 7, it is larger than 100 )
                    if (2**i - 1) >= round(pile/2) and i >= 2: # if i power of 2 minus 1 is larger or equal to round number of pile over 2 and i is larger or equal to 2
                        take = pile - (2**(i) - 1) # the number it takes from the pile is the amount of i power of 2 minus 1 as a take
                        break #
                if take <= 0: # if take is equal to or lower than 0 ( which means there is nothing to take)
                    take = randint(1, round((pile - 1)/2)) # choose number between 1 and half amount of the pile (maximum) for take amount
                pile -= take # takes out the amount that was taken from the pile (figuring out reaming # of pile)

            
            # Update pile
            print("The computer took %d marbles, leaving %d.\n" % (take, pile))
            # take is the variable you might need above
            turn = HUMAN

        elif turn == HUMAN:
            print("Your turn.   The pile currently has", pile, "marbles in it.")

            take = int(input("How many marbles will you take? "))
            # Force the user to take a legal number of marbles.
            if take > pile / 2 or take < 0: # if number that user take is more than half of the pile or less than 0,
                print('Incorrect amount of marbles') # indicate incorrect amount of marbles
                turn = HUMAN # goes again to Human turn to pick the right number

            # Update pile
            else: #else from if appeared in human turn
                pile -= take # takes out the amount that was taken from the pile (figuring out reaming # of pile)
                print("Now the pile has", pile, "marbles in it.\n")
                turn = COMPUTER

    return turn == COMPUTER

if nim(pile,turn, strategy):
    print("You Won!")
else:
    print("The computer won!")
