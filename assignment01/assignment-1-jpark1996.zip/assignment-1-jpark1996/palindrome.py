def isPalindrome(s):
    if len(s) <= 1: # if the length of the string is equal or smaller than 1 it goes to very next line, if not it is false so goes to next elif function. 
        return True # it returns true (end of the function which means the string is palindrome)
    elif s[0] == s[-1]: #if first letter and the last letter of the string is same, 
        return isPalindrome(s[1:-1]) # it removes the first and last letter of the string in this function and loops back first if statement. 
    else: # if not,
        return False # it returns false (End of the function which means the string is not palindrome)

inputString = input("Enter a string: ") # set the inputstring which user can write down a string they want
if isPalindrome(inputString): # if the string that user right down is palindrome, 
    print("That's a palindrome.") # print that it is a palindrome
else: # if not,
    print("That isn't a palindrome.") # print that it is not a palindrome. 
