def factor(n):
    i = 2 # Set i with the lowest possible prime number
    prime_factors = [] # I will going to store the result in this bracket and that is why bracket is empty currently. 
    while i * i <= n: # while i*i is equal or less than n, go to next fuction / it stops when i*i is more than n (then it goes to next if function)
        if n % i: # if n modulo i  
            i += 1 # add 1 to i and go up to while function
        else:
            n //= i #if not, n divided by i (changes n value) and go back to while agian
            prime_factors.append(i) # add i to the list 
    if n > 1: # if value of n is bigger than 1
        prime_factors.append(n) # n is added to the list ( last step of the function)
    return prime_factors # function ends. 

print (factor(int(input('write the number:')))) #print the result after user put input down






