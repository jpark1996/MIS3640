import random # import random to assign random numbers 
import turtle # import turtle to draw (drawing function)

def drunkard_walk(x, y, n):
    """
    x, y: the original location
    n: the number of intersections(steps)
    return the distance after n intersections(steps) from the origin
    """
    drunkard = turtle.Turtle() # assign drunkard to turtle in order to draw it in the turtle (drawing) function

    for i in range(n): # repeating same prodcedure until i reaches n.
        step = random.randint(0, 3) # generate random interger between 0 to 3 
        if step == 0: # when randomly slected number is 0, 
            x += 1 # x move 1 forward 
            drunkard.seth(0) # since moving right, doesn't require any angle so its 0. 
        elif step == 1: # when randomly slected number is 1,
            x -= 1 # x move 1 backward
            drunkard.seth(180) # since, we want it to move left, set angle as 180 degree to move left.
        elif step == 2: # when randomly slected number is 2,
            y += 1 # y move 1 forward  
            drunkard.seth(90) #since, we want it to move up, set angle as 90 degree to move up
        else: # when randomly slected number is 3,
            y -= 1 # y move 1 backward
            drunkard.seth(270) # since, wee want it to move down, set angle as 270 degree to move down.
        drunkard.fd(15) # one block's length is 15.

    return abs(x) + abs(y) # in order to get the total distance from the original place, add absolute value of x and y 


x = 0 # starting point of x
y = 0 # starting point of y
n = 15 # going to produce random numbers for 15 times. 

print("The drunkard started from (%d,%d)." % (x, y))
distance = drunkard_walk(x, y, n)
print("After", n, "intersections, he's",
      distance, "blocks from where he started.")

turtle.mainloop() # end the turtle loop